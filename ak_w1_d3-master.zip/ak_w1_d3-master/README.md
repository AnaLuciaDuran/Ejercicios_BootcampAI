# ak_w1_d3
github, files, strings, lists and dictionaries
